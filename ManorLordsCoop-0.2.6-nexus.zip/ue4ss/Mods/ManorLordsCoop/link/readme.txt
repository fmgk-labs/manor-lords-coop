Manor Lords Co-op keeps its log files here. Safe to delete while the game is closed.
